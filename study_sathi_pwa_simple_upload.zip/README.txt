STUDY SATHI PWA — SIMPLE PHONE UPLOAD

Upload these four files directly into the ROOT of your GitHub repository:
- index.html
- manifest.json
- service-worker.js
- study-sathi.svg

Do not put them inside another folder.

Then open repository Settings > Pages.
Under Build and deployment, choose Deploy from a branch.
Select branch main and folder /(root), then Save.
Wait for GitHub Pages to show the published URL.

Open the exact URL in Chrome on Android, then use the three-dot menu and choose Install app or Add to Home screen.

This is an installable web app (PWA), not an APK. Public repository files and the published website are visible on the internet, so do not upload passwords, private records, or student personal information.
